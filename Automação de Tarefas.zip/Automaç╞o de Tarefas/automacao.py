#Passo a Passo
#pyautogui.hotkey() -> Junta Teclas

import pyautogui
import time
import pandas as pd

pyautogui.PAUSE = 1.4
pyautogui.press("win")
pyautogui.write("chrome")
pyautogui.press("enter")

pyautogui.PAUSE = 1.4
pyautogui.write("https://dlp.hashtagtreinamentos.com/python/intensivao/login")
pyautogui.press("enter")

pyautogui.PAUSE = 0.5   
pyautogui.click(x=814, y=438)
pyautogui.write("Kevin@claro.com.br")
pyautogui.press("tab")
pyautogui.write("Kevinclaro190384")
pyautogui.press("tab")
pyautogui.press("enter")

time.sleep(1.5)

tabela = pd.read_csv("produtos.csv")
print(tabela)

pyautogui.PAUSE = 0.55
for linha in tabela.index:
    pyautogui.click(x=776, y=309)
    codigo = tabela.loc[linha, "codigo"]
    pyautogui.write(str(codigo))
    pyautogui.press("tab")
    pyautogui.write(str(tabela.loc[linha,"marca"]))
    pyautogui.press("tab")
    pyautogui.write(str(tabela.loc[linha,"tipo"]))
    pyautogui.press("tab")
    pyautogui.write(str(tabela.loc[linha,"categoria"]))
    pyautogui.press("tab")
    pyautogui.write(str(tabela.loc[linha,"preco_unitario"]))
    pyautogui.press("tab")
    pyautogui.write(str(tabela.loc[linha,"custo"]))
    pyautogui.press("tab")
    obs = tabela.loc[linha,"obs"]
    if not pd.isna(tabela.loc[linha,"obs"]):
        pyautogui.write(tabela.loc[linha,"obs"])
    pyautogui.press("tab")
    pyautogui.press("enter")

    pyautogui.scroll(5000)
    time.sleep(0.2)
#Parar