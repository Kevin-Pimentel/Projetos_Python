import time
import pyautogui

time.sleep(6)
print(pyautogui.position())